BEST DEALS 254 — CONNECTED V1

Configured Supabase project:
https://txiomgyaxkzurhydzaym.supabase.co

Included:
- customer.html: live product catalog + cart + order creation
- admin.html: admin login + live inventory + order management
- schema_fix.sql: security fixes for the database setup
- best-deals-logo.png: owner-provided logo

IMPORTANT:
The publishable key is intentionally used in the browser. Never add a Supabase secret/service_role key to these files.

Before production deployment, add:
- Supabase Storage product images
- atomic stock reservation/decrement when an order is placed
- customer accounts/order history
- M-Pesa Daraja payment flow
- delivery tracking
- server-side validation/rate limiting
- production hosting/domain and HTTPS
