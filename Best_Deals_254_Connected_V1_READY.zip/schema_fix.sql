-- Best Deals 254: security fixes for the existing schema
-- Run this after the original database setup if needed.

alter table public.profiles enable row level security;

drop policy if exists "Users view own profile" on public.profiles;
create policy "Users view own profile"
on public.profiles
for select
to authenticated
using (id = auth.uid());

-- Allow admins to view all orders and their order items.
drop policy if exists "Admins view all orders" on public.orders;
create policy "Admins view all orders"
on public.orders
for select
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
);

-- Allow admins to update order status.
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders"
on public.orders
for update
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
)
with check (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
);
